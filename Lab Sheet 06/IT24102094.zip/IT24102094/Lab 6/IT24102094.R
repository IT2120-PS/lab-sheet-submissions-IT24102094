setwd("C:\\Users\\IT24102094\\Desktop\\IT24102094\\Lab 6")

##Question 1
#part 1
#Binomial Distribution
#n=44 and p=0.92

#part 2
dbinom(40,44,0.92)

#part 3
#P(x<=35)
pbinom(35,44,0.92,lower.tail = TRUE)

#part 4
#P(x>=38) 
#P(x>=38) = 1-P(x<38) = 1-P(x>=37)
1-pbinom(37,44,0.92,lower.tail = TRUE)
#or
pbinom(37,44,0.92,lower.tail = FALSE)

#part 5 
#P(40<=x<=42)
pbinom(42,44,0.92,lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail = TRUE)

#Question 2
#part 1
#5

#part 2
#poisson distribution
#lambda=5

#part 3 
#P(x=6)
dpois(6,5)

#part 4
#P(x>6)
ppois(6,5,lower.tail=FALSE)

#Exercise

#Question 1
#part 1
#X(n=50,p=0.85)

#part 2
pbinom(47,50,0.85,lower.tail = FALSE)

#Question 2
#part 1
#X=number of calls received in one hour

#part 2
#lambda 12

#part 3
dpois(15,12)