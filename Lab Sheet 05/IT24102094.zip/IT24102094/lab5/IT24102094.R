# Set working directory
setwd("C:\\Users\\IT24102094\\Desktop\\IT24102094\\lab5") 

# Import the dataset
Data <- read.table("Data.txt", header=TRUE,sep=',')

fix(Data)
names(Data)<-c("X1","X2")

attach(Data)


histogram<-hist(X2,main="Histogram for number of shareholders",
     breaks = seq(130,270,length = 8),right = FALSE)

breaks<-round(histogram$breaks) 
breaks

freq<-histogram$counts
freq

mid<-histogram$mids
mid

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i]<-paste0("[",breaks[i],",",breaks[i+1],")")
}
classes

cbind(Classes = classes ,Frequency=freq)

lines(mid,freq)

plot(mid,freq,type='l',main="Frequency ploygon for shareholders",xlab = "shareholders",ylab="frequency",ylim=c(0,max(freq)))

cum.freq <-cumsum(freq)

new<-c()

for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

new
plot(breaks,new,type='o',main="Cumulative Frequency ploygon for shareholders",xlab = "shareholders",ylab="Cumalative frequency",ylim=c(0,max(cum.freq)))

cbind(Upper = breaks, cumFreq = new)


# Set working directory
setwd("C:\\Users\\IT24102094\\Desktop\\IT24102094\\lab5") 

# Import the dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE)

fix(Delivery_Times)
names(Delivery_Times)<-c("X1")

attach(Delivery_Times)


# Histogram with 9 classes (20–70)
hist(Delivery_Times$X1,
     breaks=seq(20, 70, length.out=10),  # 9 intervals
     right=FALSE,                        # right-open intervals
     main="Histogram of Delivery Times",
     xlab="Delivery Time",
     ylab="Frequency")



# Create histogram without plotting
hist_data <- hist(Delivery_Times$X1,
                  breaks=seq(20, 70, length.out=10),
                  right=FALSE,
                  plot=FALSE)

# Calculate cumulative frequency
cum_freq <- cumsum(hist_data$counts)

# Plot cumulative frequency polygon (Ogive)
plot(hist_data$breaks[-1], cum_freq, type="o",
     main="Cumulative Frequency Polygon (Ogive)",
     xlab="Delivery Time",
     ylab="Cumulative Frequency")
